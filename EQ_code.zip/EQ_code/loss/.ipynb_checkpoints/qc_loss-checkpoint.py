import torch
import torch.nn as nn
import math


QM=-0.1               #权重范围j截断范围在-0.1到 0，1之间，用于计算sacle
QN=0.1
epsilon = 1e-2

class LBClamp(torch.autograd.Function):
    @staticmethod
    def forward(ctx, input, min_value, max_value):
        return torch.clamp(input, min_value, max_value)

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output, None, None

def constraint_qc(x):
    y = -(torch.log(torch.abs(torch.cos(x))))
    return y

# clamp = LBClamp.apply

# def QC_loss(x): 
#     min_value = QM - s / 2 + epsilon
#     max_value = QN + s / 2 - epsilon
#     temp = clamp(x, min_value, max_value)
#     qc = torch.sum(constraint_qc(temp/s * math.pi))
#     return qc

class QC_Loss(nn.Module):
    def __init__(self, scale):
        super(QC_Loss, self).__init__()
        self.clamp = LBClamp.apply
        self.s = scale
        
    def forward(self, x):
        min_value = QM - self.s / 2 + epsilon
        max_value = QN + self.s / 2 - epsilon
        temp = self.clamp(x, min_value, max_value)
        qc = torch.sum(constraint_qc(temp/self.s * math.pi))
        return qc