from . import alexnet, lenet, resnet, resnet_cifar10, resnet_cifar100, vgg

__all__ = ['lenet5', 'resnet18', 'resnet50', 'resnet20_cifar10', 'resnet20_cifar100', 'vgg7']
           
# def return_model(args):
#     if args.model.lower() == 'lenet5':
#         return lenet.lenet()
#     elif args.model.lower() == 'resnet18':
#         return resnet.resnet18()
#     else:
#         return "model select error"

def lenet5():
    return lenet.lenet()

def resnet18():
    return resnet.resnet18()

def resnet50():
    return resnet.ResNet50()

def resnet20_cifar10():
    return resnet_cifar10.resnet20()

def resnet20_cifar100():
    return resnet_cifar100.resnet20()

def vgg7():
    return vgg.cifar10_vggsmall()