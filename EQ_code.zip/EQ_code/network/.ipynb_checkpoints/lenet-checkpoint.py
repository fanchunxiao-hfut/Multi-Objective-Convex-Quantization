# author: songguangming time:2022/1/9
import torch.nn as nn
from torch.nn import functional as F

default_cfg = [32, 64]

# class LeNet5(nn.Module):
#     def __init__(self):
#         super(LeNet5, self).__init__()
#         self.conv1 = nn.Conv2d(1, 16, 5)
#         self.pool1 = nn.MaxPool2d(2, 2)
#         self.conv2 = nn.Conv2d(16, 32, 5)
#         self.pool2 = nn.MaxPool2d(2, 2)
#         self.fc1 = nn.Linear(32*5*5, 120)
#         self.fc2 = nn.Linear(120, 84)
#         self.fc3 = nn.Linear(84, 10)  
        
#     def forward(self, x):
#         x = F.relu(self.conv1(x))    
#         x = self.pool1(x)            
#         x = F.relu(self.conv2(x))    
#         x = self.pool2(x)            
#         x = x.view(-1, 32*5*5)      
#         x = F.relu(self.fc1(x))     
#         x = F.relu(self.fc2(x))     
#         x = self.fc3(x)             
#         return x



class LeNet5(nn.Module):
    def __init__(self):
        super(LeNet5, self).__init__()  
        self.layer = nn.Sequential(
        #in:1*1*28*28
        nn.Conv2d(1,30,kernel_size=7,stride=1,padding=2),nn.ReLU(),
        nn.MaxPool2d(kernel_size=4,stride=2,padding=1),
        nn.Conv2d(30,60,kernel_size=5,stride=1,padding=1),nn.ReLU(),
        nn.MaxPool2d(kernel_size=4,padding=1,stride=2),
        nn.Flatten(),
        nn.Linear(60*5*5,500),nn.ReLU(),nn.Dropout(0.5),
        nn.Linear(500, 10))  

    def forward(self, x):
        x = self.layer(x)      
        return x

         


def lenet():
    return LeNet5()
